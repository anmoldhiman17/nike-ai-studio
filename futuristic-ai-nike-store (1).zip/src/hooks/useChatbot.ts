import { useState, useCallback } from 'react';
import { Message } from '../types';
import { aiResponses } from '../data/products';

export const useChatbot = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: aiResponses.greeting[0],
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [isOpen, setIsOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const getAIResponse = useCallback((userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('help') || lowerMessage.includes('assist')) {
      return aiResponses.help[Math.floor(Math.random() * aiResponses.help.length)];
    }
    
    if (lowerMessage.includes('recommend') || lowerMessage.includes('suggest')) {
      return aiResponses.recommendation[Math.floor(Math.random() * aiResponses.recommendation.length)];
    }
    
    if (lowerMessage.includes('cart') || lowerMessage.includes('buy')) {
      return aiResponses.cart[Math.floor(Math.random() * aiResponses.cart.length)];
    }
    
    if (lowerMessage.includes('price') || lowerMessage.includes('cost')) {
      return "Our Nike shoes range from $99 to $299, depending on the model and technology. All prices include premium quality and authentic Nike craftsmanship!";
    }
    
    if (lowerMessage.includes('size') || lowerMessage.includes('sizing')) {
      return "We offer sizes from 7 to 13 for most models. Nike shoes typically fit true to size, but I recommend checking our size guide for the perfect fit!";
    }
    
    if (lowerMessage.includes('shipping') || lowerMessage.includes('delivery')) {
      return "We offer free shipping on orders over $150! Standard delivery takes 3-5 business days, and express shipping is available for faster delivery.";
    }
    
    if (lowerMessage.includes('return') || lowerMessage.includes('exchange')) {
      return "We have a 30-day return policy! If you're not completely satisfied, you can return or exchange your shoes within 30 days of purchase.";
    }
    
    if (lowerMessage.includes('running') || lowerMessage.includes('run')) {
      return "For running, I highly recommend the Nike Air Max Pulse or ZoomX Vaporfly! They offer exceptional cushioning and support for all distances.";
    }
    
    if (lowerMessage.includes('basketball')) {
      return "The Nike Air Jordan 1 is a legendary basketball shoe! It combines iconic style with performance features that athletes love.";
    }
    
    if (lowerMessage.includes('lifestyle') || lowerMessage.includes('casual')) {
      return "For everyday wear, check out the Nike Dunk Low Retro or Blazer Mid 77! They're stylish, comfortable, and perfect for any casual occasion.";
    }
    
    if (lowerMessage.includes('hi') || lowerMessage.includes('hello') || lowerMessage.includes('hey')) {
      return aiResponses.greeting[Math.floor(Math.random() * aiResponses.greeting.length)];
    }
    
    if (lowerMessage.includes('thank')) {
      return "You're welcome! Happy to help you find the perfect Nike shoes! 😊";
    }
    
    // Default response
    return aiResponses.productQuery[Math.floor(Math.random() * aiResponses.productQuery.length)];
  }, []);

  const sendMessage = useCallback((text: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Simulate AI thinking delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(text),
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  }, [getAIResponse]);

  const clearMessages = useCallback(() => {
    setMessages([{
      id: '1',
      text: aiResponses.greeting[0],
      sender: 'ai',
      timestamp: new Date()
    }]);
  }, []);

  return {
    messages,
    isOpen,
    setIsOpen,
    isTyping,
    sendMessage,
    clearMessages
  };
};
