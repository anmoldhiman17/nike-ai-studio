import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sphere, Stars, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

function FloatingParticles() {
  const points = useRef<THREE.Points>(null);
  const particlesCount = 200;

  const positions = useMemo(() => {
    const positions = new Float32Array(particlesCount * 3);
    for (let i = 0; i < particlesCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
    }
    return positions;
  }, []);

  useFrame((state) => {
    if (!points.current) return;
    points.current.rotation.y = state.clock.elapsedTime * 0.05;
    points.current.rotation.x = state.clock.elapsedTime * 0.02;
  });

  const positionAttribute = useMemo(() => {
    const attr = new THREE.BufferAttribute(positions, 3);
    return attr;
  }, [positions]);

  return (
    <points ref={points}>
      <bufferGeometry>
        <primitive attach="attributes-position" object={positionAttribute} />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color="#8b5cf6"
        transparent
        opacity={0.8}
        sizeAttenuation
      />
    </points>
  );
}

function FloatingSpheres() {
  const group = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!group.current) return;
    group.current.rotation.y = state.clock.elapsedTime * 0.1;
  });

  return (
    <group ref={group}>
      <Float speed={2} rotationIntensity={2} floatIntensity={2}>
        <Sphere args={[1, 100, 100]} position={[-3, 1, -5]}>
          <MeshDistortMaterial
            color="#8b5cf6"
            attach="material"
            distort={0.4}
            speed={2}
            roughness={0.2}
            metalness={0.8}
          />
        </Sphere>
      </Float>

      <Float speed={3} rotationIntensity={1.5} floatIntensity={1.5}>
        <Sphere args={[0.7, 100, 100]} position={[3, -1, -3]}>
          <MeshDistortMaterial
            color="#3b82f6"
            attach="material"
            distort={0.3}
            speed={3}
            roughness={0.2}
            metalness={0.8}
          />
        </Sphere>
      </Float>

      <Float speed={1.5} rotationIntensity={2.5} floatIntensity={1}>
        <Sphere args={[0.5, 100, 100]} position={[0, 2, -4]}>
          <MeshDistortMaterial
            color="#06b6d4"
            attach="material"
            distort={0.5}
            speed={1.5}
            roughness={0.2}
            metalness={0.8}
          />
        </Sphere>
      </Float>
    </group>
  );
}

function ConnectingLines() {
  const lineGeometry = useMemo(() => {
    const points = [
      new THREE.Vector3(-3, 1, -5),
      new THREE.Vector3(3, -1, -3),
      new THREE.Vector3(0, 2, -4),
      new THREE.Vector3(-3, 1, -5)
    ];
    return new THREE.BufferGeometry().setFromPoints(points);
  }, []);

  return (
    <primitive object={new THREE.Line(lineGeometry, new THREE.LineBasicMaterial({ color: '#8b5cf6', transparent: true, opacity: 0.3 }))} />
  );
}

export default function Scene3D() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 10], fov: 45 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#8b5cf6" />
        
        <Stars
          radius={100}
          depth={50}
          count={1000}
          factor={4}
          saturation={0.5}
          fade
        />
        
        <FloatingParticles />
        <FloatingSpheres />
        <ConnectingLines />
      </Canvas>
    </div>
  );
}
