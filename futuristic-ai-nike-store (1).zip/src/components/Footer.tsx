import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Heart, Share2, MessageCircle, Zap, Globe } from 'lucide-react';

const Footer: React.FC = () => {
  const socialLinks = [
    { icon: <Share2 className="w-5 h-5" />, href: '#', label: 'Share' },
    { icon: <MessageCircle className="w-5 h-5" />, href: '#', label: 'Message' },
    { icon: <Zap className="w-5 h-5" />, href: '#', label: 'Connect' },
    { icon: <Globe className="w-5 h-5" />, href: '#', label: 'Website' },
  ];

  const footerLinks = [
    {
      title: 'Product',
      links: ['Features', 'Pricing', 'FAQ', 'Support'],
    },
    {
      title: 'Company',
      links: ['About', 'Blog', 'Careers', 'Contact'],
    },
    {
      title: 'Legal',
      links: ['Privacy', 'Terms', 'Security', 'Cookies'],
    },
  ];

  return (
    <footer className="relative mt-20 border-t border-white/10 bg-gradient-to-b from-transparent to-black/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center space-x-2 mb-4"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center glow-purple">
                <span className="text-white font-bold text-xl">N</span>
              </div>
              <div>
                <h3 className="text-lg font-bold gradient-text">NIKE AI STUDIO</h3>
              </div>
            </motion.div>
            <p className="text-sm text-gray-400 mb-4">
              The future of sneaker shopping, powered by artificial intelligence.
            </p>
            <div className="flex items-center space-x-3">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  whileHover={{ scale: 1.2, y: -2 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-9 h-9 glass rounded-lg flex items-center justify-center hover:glass-strong transition-all"
                  aria-label={social.label}
                >
                  <div className="text-purple-400">{social.icon}</div>
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((section, index) => (
            <div key={index}>
              <h4 className="text-white font-bold mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <motion.a
                      href="#"
                      whileHover={{ x: 4 }}
                      className="text-gray-400 hover:text-purple-400 transition-colors text-sm"
                    >
                      {link}
                    </motion.a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass rounded-2xl p-6 mb-8 border border-purple-500/20"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className="text-white font-bold">Stay Updated</h4>
                <p className="text-sm text-gray-400">Get the latest drops and AI features</p>
              </div>
            </div>
            <div className="flex w-full md:w-auto gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 md:w-64 px-4 py-3 glass-strong rounded-lg text-white placeholder-gray-400 border border-white/10 focus:border-purple-500/50 focus:outline-none"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white font-medium glow-purple hover:from-purple-700 hover:to-pink-700 transition-all"
              >
                Subscribe
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-400 text-center md:text-left">
            © 2024 Nike AI Studio. All rights reserved.
          </p>
          <div className="flex items-center space-x-1 text-sm text-gray-400">
            <span>Built with</span>
            <Heart className="w-4 h-4 text-red-500 fill-red-500 mx-1" />
            <span>using AI & React</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
