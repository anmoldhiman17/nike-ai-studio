import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Wand2, Code, Palette, Zap, RefreshCw, Download, Eye } from 'lucide-react';

interface AIGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (prompt: string, config: any) => void;
}

const AIGenerator: React.FC<AIGeneratorProps> = ({ isOpen, onClose, onGenerate }) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedHTML, setGeneratedHTML] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState('neon');
  const [selectedLayout, setSelectedLayout] = useState('modern');

  const themes = [
    { id: 'neon', name: 'Neon Dark', color: 'from-purple-600 to-pink-600' },
    { id: 'luxury', name: 'Luxury Gold', color: 'from-yellow-600 to-orange-600' },
    { id: 'ocean', name: 'Ocean Blue', color: 'from-blue-600 to-cyan-600' },
    { id: 'forest', name: 'Forest Green', color: 'from-green-600 to-emerald-600' },
  ];

  const layouts = [
    { id: 'modern', name: 'Modern Grid' },
    { id: 'classic', name: 'Classic List' },
    { id: 'futuristic', name: 'Futuristic' },
    { id: 'minimal', name: 'Minimal' },
  ];

  const enhanceOptions = [
    { icon: <Wand2 />, text: 'Make it futuristic', action: 'futuristic' },
    { icon: <Zap />, text: 'Add animations', action: 'animations' },
    { icon: <Palette />, text: 'Change colors', action: 'colors' },
    { icon: <Code />, text: 'Optimize code', action: 'optimize' },
  ];

  const handleGenerate = () => {
    setIsGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      const config = {
        theme: selectedTheme,
        layout: selectedLayout,
        prompt: prompt,
      };
      
      onGenerate(prompt, config);
      
      // Generate mock HTML
      const mockHTML = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${prompt || 'AI Generated Nike Store'}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      color: white;
      min-height: 100vh;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 40px 20px;
    }
    .hero {
      text-align: center;
      padding: 80px 20px;
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(236, 72, 153, 0.2));
      border-radius: 24px;
      margin-bottom: 40px;
    }
    h1 {
      font-size: 3rem;
      background: linear-gradient(135deg, #8b5cf6, #ec4899);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 20px;
    }
    .products {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 24px;
    }
    .card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 16px;
      padding: 20px;
      border: 1px solid rgba(139, 92, 246, 0.3);
      transition: transform 0.3s, box-shadow 0.3s;
    }
    .card:hover {
      transform: translateY(-8px);
      box-shadow: 0 20px 40px rgba(139, 92, 246, 0.3);
    }
    .btn {
      background: linear-gradient(135deg, #8b5cf6, #ec4899);
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 8px;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="hero">
      <h1>${prompt || 'AI-Powered Nike Store'}</h1>
      <p>Experience the future of shopping</p>
    </div>
    <div class="products">
      <div class="card"><h3>Nike Air Max</h3><p>$189.99</p><button class="btn">Add to Cart</button></div>
      <div class="card"><h3>Nike Jordan 1</h3><p>$249.99</p><button class="btn">Add to Cart</button></div>
      <div class="card"><h3>Nike Dunk Low</h3><p>$129.99</p><button class="btn">Add to Cart</button></div>
    </div>
  </div>
</body>
</html>`;
      
      setGeneratedHTML(mockHTML);
      setIsGenerating(false);
      setShowPreview(true);
    }, 3000);
  };

  const handleEnhance = (_action: string) => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      // Trigger visual feedback
    }, 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />

          {/* Generator Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-4 md:inset-10 glass-strong border border-purple-500/30 rounded-3xl z-50 overflow-hidden flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/10 bg-gradient-to-r from-purple-600/20 to-pink-600/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center glow-purple">
                    <Wand2 className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold gradient-text">AI Website Generator</h2>
                    <p className="text-sm text-gray-400">Create stunning websites with AI</p>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onClose}
                  className="w-10 h-10 rounded-full glass flex items-center justify-center hover:glass-strong transition-all"
                >
                  <X className="w-6 h-6 text-gray-300" />
                </motion.button>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden flex">
              {/* Left Panel - Controls */}
              <div className="w-full md:w-96 p-6 space-y-6 overflow-y-auto border-r border-white/10">
                {/* Prompt Input */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-300">Describe your website</label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="e.g., Create a luxury Nike sneaker store with dark theme and neon accents..."
                    className="w-full h-32 px-4 py-3 glass-strong rounded-xl text-white placeholder-gray-400 border border-white/10 focus:border-purple-500/50 focus:outline-none resize-none transition-all"
                  />
                </div>

                {/* Theme Selector */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-300">Theme</label>
                  <div className="grid grid-cols-2 gap-2">
                    {themes.map((theme) => (
                      <motion.button
                        key={theme.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setSelectedTheme(theme.id)}
                        className={`p-3 rounded-xl border-2 transition-all ${
                          selectedTheme === theme.id
                            ? 'border-purple-500 bg-purple-500/10'
                            : 'border-white/10 glass hover:border-white/20'
                        }`}
                      >
                        <div className={`h-8 rounded-lg bg-gradient-to-r ${theme.color} mb-2`} />
                        <p className="text-sm font-medium text-white">{theme.name}</p>
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Layout Selector */}
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-300">Layout</label>
                  <div className="grid grid-cols-2 gap-2">
                    {layouts.map((layout) => (
                      <motion.button
                        key={layout.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setSelectedLayout(layout.id)}
                        className={`p-3 rounded-xl border transition-all ${
                          selectedLayout === layout.id
                            ? 'border-purple-500 bg-purple-500/10 text-white'
                            : 'border-white/10 glass text-gray-400 hover:text-white'
                        }`}
                      >
                        <p className="text-sm font-medium">{layout.name}</p>
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Generate Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleGenerate}
                  disabled={isGenerating || !prompt}
                  className="w-full flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl text-white font-bold glow-purple hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span>Generating...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-5 h-5" />
                      <span>Generate Website</span>
                    </>
                  )}
                </motion.button>

                {/* Enhance Options */}
                {showPreview && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    <label className="text-sm font-medium text-gray-300">Enhance Your Website</label>
                    <div className="grid grid-cols-2 gap-2">
                      {enhanceOptions.map((option) => (
                        <motion.button
                          key={option.action}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleEnhance(option.action)}
                          className="flex items-center space-x-2 p-3 glass rounded-xl hover:glass-strong transition-all"
                        >
                          <div className="text-purple-400">{option.icon}</div>
                          <span className="text-xs font-medium text-white">{option.text}</span>
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Right Panel - Preview */}
              <div className="flex-1 flex flex-col bg-black/20">
                {isGenerating ? (
                  <div className="flex-1 flex flex-col items-center justify-center p-8">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                      className="w-20 h-20 border-4 border-purple-500/30 border-t-purple-500 rounded-full mb-6"
                    />
                    <h3 className="text-2xl font-bold gradient-text mb-2">AI is generating...</h3>
                    <p className="text-gray-400 text-center max-w-md">
                      Our AI is analyzing your requirements and creating a custom website tailored to your needs.
                    </p>
                    <div className="flex space-x-1 mt-6">
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce loading-dot" />
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce loading-dot" />
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce loading-dot" />
                    </div>
                  </div>
                ) : showPreview ? (
                  <>
                    {/* Preview Header */}
                    <div className="p-4 border-b border-white/10 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Eye className="w-5 h-5 text-purple-400" />
                        <span className="text-sm font-medium text-white">Live Preview</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="px-3 py-2 glass rounded-lg text-sm font-medium hover:glass-strong transition-all flex items-center space-x-2"
                        >
                          <Download className="w-4 h-4" />
                          <span>Export</span>
                        </motion.button>
                      </div>
                    </div>
                    
                    {/* Preview Frame */}
                    <div className="flex-1 p-4 overflow-auto">
                      <div className="w-full h-full glass rounded-xl overflow-hidden">
                        <iframe
                          srcDoc={generatedHTML}
                          className="w-full h-full border-0"
                          title="Generated Website Preview"
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                    <div className="w-24 h-24 bg-purple-600/10 rounded-full flex items-center justify-center mb-6">
                      <Wand2 className="w-12 h-12 text-purple-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Ready to Create Magic?</h3>
                    <p className="text-gray-400 max-w-md">
                      Enter your website description and watch as AI brings your vision to life in real-time.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AIGenerator;
