import { motion } from 'framer-motion';
import { useState } from 'react';
import { Sparkles, Zap, Shield, Globe, Cpu, Palette } from 'lucide-react';

interface BentoItem {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  size: 'small' | 'medium' | 'large' | 'wide';
  gradient: string;
}

const bentoItems: BentoItem[] = [
  {
    id: '1',
    title: 'AI Generation',
    description: 'Transform your ideas into stunning websites with our advanced AI engine that understands design principles and user experience.',
    icon: <Sparkles className="w-6 h-6" />,
    size: 'large',
    gradient: 'from-purple-500/20 to-blue-500/20'
  },
  {
    id: '2',
    title: 'Lightning Fast',
    description: 'Optimized performance with sub-second load times and 99.9% uptime guarantee for your digital storefront.',
    icon: <Zap className="w-5 h-5" />,
    size: 'small',
    gradient: 'from-yellow-500/20 to-orange-500/20'
  },
  {
    id: '3',
    title: 'Secure Payments',
    description: 'Bank-level encryption and fraud protection for all transactions.',
    icon: <Shield className="w-5 h-5" />,
    size: 'small',
    gradient: 'from-green-500/20 to-emerald-500/20'
  },
  {
    id: '4',
    title: 'Global CDN',
    description: 'Deliver content from 200+ edge locations worldwide for instant access anywhere on the planet.',
    icon: <Globe className="w-5 h-5" />,
    size: 'wide',
    gradient: 'from-blue-500/20 to-cyan-500/20'
  },
  {
    id: '5',
    title: 'Smart Analytics',
    description: 'Real-time insights into customer behavior and sales performance.',
    icon: <Cpu className="w-5 h-5" />,
    size: 'medium',
    gradient: 'from-pink-500/20 to-rose-500/20'
  },
  {
    id: '6',
    title: 'Custom Themes',
    description: 'Unlimited customization options with our visual theme builder.',
    icon: <Palette className="w-5 h-5" />,
    size: 'medium',
    gradient: 'from-violet-500/20 to-purple-500/20'
  }
];

export default function BentoGrid() {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const getGridClass = (size: string) => {
    switch (size) {
      case 'large':
        return 'md:col-span-2 md:row-span-2';
      case 'wide':
        return 'md:col-span-2';
      case 'medium':
        return 'md:col-span-1';
      default:
        return '';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
      {bentoItems.map((item) => (
        <motion.div
          key={item.id}
          className={`relative overflow-hidden rounded-2xl ${getGridClass(item.size)} min-h-[200px]`}
          onMouseEnter={() => setHoveredId(item.id)}
          onMouseLeave={() => setHoveredId(null)}
          whileHover={{ scale: 0.98 }}
          transition={{ duration: 0.3 }}
        >
          {/* Background gradient */}
          <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-50`} />
          
          {/* Glass effect */}
          <div 
            className="absolute inset-0 backdrop-blur-xl"
            style={{
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
            }}
          />
          
          {/* Hover glow */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent"
            animate={{ opacity: hoveredId === item.id ? 1 : 0 }}
            transition={{ duration: 0.3 }}
          />
          
          {/* Content */}
          <div className="relative z-10 h-full p-6 flex flex-col">
            <motion.div
              className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4"
              animate={{ 
                rotate: hoveredId === item.id ? [0, -10, 10, 0] : 0,
                scale: hoveredId === item.id ? 1.1 : 1
              }}
              transition={{ duration: 0.5 }}
            >
              {item.icon}
            </motion.div>
            
            <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
            <p className="text-sm text-white/60 leading-relaxed">{item.description}</p>
            
            {/* Animated border on hover */}
            <motion.div
              className="absolute inset-0 rounded-2xl pointer-events-none"
              style={{
                border: '1px solid rgba(139, 92, 246, 0.3)',
              }}
              animate={{ opacity: hoveredId === item.id ? 1 : 0 }}
            />
          </div>
          
          {/* Corner accent */}
          <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden">
            <motion.div
              className="absolute top-0 right-0 w-full h-full bg-gradient-to-bl from-white/10 to-transparent"
              animate={{ opacity: hoveredId === item.id ? 1 : 0 }}
              style={{ transform: 'translate(50%, -50%) rotate(45deg)' }}
            />
          </div>
        </motion.div>
      ))}
    </div>
  );
}
