import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, Zap, Award } from 'lucide-react';

const Stats: React.FC = () => {
  const [counters, setCounters] = useState({
    products: 0,
    users: 0,
    speed: 0,
    rating: 0,
  });

  const stats = [
    {
      icon: <TrendingUp className="w-8 h-8" />,
      value: 500,
      suffix: '+',
      label: 'Premium Products',
      key: 'products',
      gradient: 'from-purple-600 to-pink-600',
    },
    {
      icon: <Users className="w-8 h-8" />,
      value: 10000,
      suffix: '+',
      label: 'Happy Customers',
      key: 'users',
      gradient: 'from-blue-600 to-cyan-600',
    },
    {
      icon: <Zap className="w-8 h-8" />,
      value: 99,
      suffix: '%',
      label: 'Performance Score',
      key: 'speed',
      gradient: 'from-yellow-600 to-orange-600',
    },
    {
      icon: <Award className="w-8 h-8" />,
      value: 4.9,
      suffix: '/5',
      label: 'Average Rating',
      key: 'rating',
      gradient: 'from-green-600 to-emerald-600',
    },
  ];

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const interval = duration / steps;

    const timers = stats.map((stat) => {
      let current = 0;
      const increment = stat.value / steps;

      return setInterval(() => {
        current += increment;
        if (current >= stat.value) {
          current = stat.value;
          clearInterval(timers[stats.indexOf(stat)]);
        }
        setCounters((prev) => ({
          ...prev,
          [stat.key]: stat.key === 'rating' ? parseFloat(current.toFixed(1)) : Math.floor(current),
        }));
      }, interval);
    });

    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-900/10 via-transparent to-pink-900/10" />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-4">
            Trusted by Thousands
          </h2>
          <p className="text-lg text-gray-400">
            Join our community of sneaker enthusiasts and experience the future
          </p>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.key}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="glass rounded-2xl p-6 border border-white/10 hover:border-purple-500/30 transition-all"
            >
              <div
                className={`w-16 h-16 bg-gradient-to-br ${stat.gradient} rounded-xl flex items-center justify-center mb-4 mx-auto`}
              >
                <div className="text-white">{stat.icon}</div>
              </div>
              <div className="text-center">
                <motion.p
                  className="text-3xl md:text-4xl font-bold gradient-text mb-1"
                  key={counters[stat.key as keyof typeof counters]}
                >
                  {counters[stat.key as keyof typeof counters]}
                  {stat.suffix}
                </motion.p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
