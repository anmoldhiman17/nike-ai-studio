import { motion } from 'framer-motion';
import { useState } from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
  glowColor?: string;
}

export default function GlassCard({ 
  children, 
  className = '', 
  hoverEffect = true,
  glowColor = 'from-purple-500/20 via-blue-500/20 to-cyan-500/20'
}: GlassCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      className={`relative overflow-hidden ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={hoverEffect ? { 
        y: -10, 
        scale: 1.02,
        transition: { duration: 0.4, ease: [0.23, 1, 0.32, 1] }
      } : {}}
    >
      {/* Glass background */}
      <div 
        className="absolute inset-0 rounded-2xl backdrop-blur-xl"
        style={{
          background: 'rgba(255, 255, 255, 0.03)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          boxShadow: isHovered 
            ? '0 25px 50px -12px rgba(139, 92, 246, 0.25), inset 0 1px 0 0 rgba(255, 255, 255, 0.1)' 
            : '0 10px 30px -10px rgba(0, 0, 0, 0.5), inset 0 1px 0 0 rgba(255, 255, 255, 0.05)',
        }}
      />
      
      {/* Animated gradient glow */}
      <motion.div
        className={`absolute -inset-px rounded-2xl bg-gradient-to-r ${glowColor} blur-xl`}
        animate={{
          opacity: isHovered ? 0.6 : 0,
          scale: isHovered ? 1.1 : 1,
        }}
        transition={{ duration: 0.5 }}
      />
      
      {/* Inner gradient border */}
      <div 
        className="absolute inset-0 rounded-2xl pointer-events-none"
        style={{
          background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(255,255,255,0.05) 100%)',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          borderRadius: '1rem',
        }}
      />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
}
