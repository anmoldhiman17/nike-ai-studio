import { motion } from 'framer-motion';

interface AnimatedGradientProps {
  className?: string;
  variant?: 'purple' | 'blue' | 'mixed' | 'rainbow';
}

export default function AnimatedGradient({ 
  className = '', 
  variant = 'mixed' 
}: AnimatedGradientProps) {
  const getGradient = () => {
    switch (variant) {
      case 'purple':
        return 'from-purple-600/30 via-fuchsia-500/20 to-purple-800/30';
      case 'blue':
        return 'from-blue-600/30 via-cyan-500/20 to-blue-800/30';
      case 'rainbow':
        return 'from-red-500/20 via-yellow-500/20 via-green-500/20 via-blue-500/20 via-purple-500/20 to-pink-500/20';
      default:
        return 'from-purple-600/30 via-blue-500/20 via-cyan-500/20 to-purple-800/30';
    }
  };

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`}>
      {/* Primary animated gradient */}
      <motion.div
        className={`absolute inset-0 bg-gradient-to-br ${getGradient()} blur-3xl`}
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 90, 0],
          x: [0, 50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
      
      {/* Secondary orb */}
      <motion.div
        className="absolute w-[600px] h-[600px] rounded-full bg-gradient-to-r from-blue-600/20 to-purple-600/20 blur-3xl"
        animate={{
          x: ['-20%', '80%', '-20%'],
          y: ['10%', '60%', '10%'],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
      
      {/* Tertiary orb */}
      <motion.div
        className="absolute w-[400px] h-[400px] rounded-full bg-gradient-to-r from-cyan-500/15 to-blue-500/15 blur-3xl"
        animate={{
          x: ['70%', '10%', '70%'],
          y: ['50%', '20%', '50%'],
          scale: [1, 0.8, 1],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
      
      {/* Noise texture overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />
    </div>
  );
}
