import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Heart, Star, Sparkles } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, color: string, size: number) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [selectedSize, setSelectedSize] = useState(product.sizes[2]);
  const [isLiked, setIsLiked] = useState(false);
  const [showQuickView, setShowQuickView] = useState(false);

  const handleAddToCart = () => {
    onAddToCart(product, selectedColor, selectedSize);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        className="group relative"
      >
        <div className="relative glass rounded-2xl overflow-hidden border border-white/10 hover:border-purple-500/30 transition-all duration-300">
          {/* Image Container */}
          <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-purple-900/20 to-pink-900/20">
            <motion.img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              whileHover={{ scale: 1.1 }}
              transition={{ duration: 0.4 }}
            />
            
            {/* Overlay on Hover */}
            <AnimatePresence>
              {isHovered && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center"
                >
                  <motion.button
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    onClick={() => setShowQuickView(true)}
                    className="px-6 py-3 bg-white text-black font-bold rounded-full hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white transition-all"
                  >
                    Quick View
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Category Badge */}
            <div className="absolute top-3 left-3 px-3 py-1 glass-strong rounded-full text-xs font-medium text-purple-300 border border-purple-500/30">
              {product.category}
            </div>

            {/* Like Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsLiked(!isLiked)}
              className="absolute top-3 right-3 w-10 h-10 glass-strong rounded-full flex items-center justify-center border border-white/10 hover:border-pink-500/50 transition-all"
            >
              <Heart
                className={`w-5 h-5 ${isLiked ? 'fill-pink-500 text-pink-500' : 'text-white'}`}
              />
            </motion.button>

            {/* Rating */}
            <div className="absolute bottom-3 left-3 flex items-center space-x-1 px-2 py-1 glass-strong rounded-full">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-bold text-white">{product.rating}</span>
            </div>
          </div>

          {/* Content */}
          <div className="p-4 space-y-3">
            {/* Title and Price */}
            <div>
              <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                {product.name}
              </h3>
              <p className="text-sm text-gray-400 line-clamp-2">{product.description}</p>
            </div>

            {/* Color Selector */}
            <div className="space-y-2">
              <p className="text-xs text-gray-400 font-medium">Colors</p>
              <div className="flex items-center space-x-2">
                {product.colors.map((color) => (
                  <motion.button
                    key={color}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full border-2 ${
                      selectedColor === color
                        ? 'border-purple-500 shadow-lg shadow-purple-500/50'
                        : 'border-gray-600'
                    } transition-all`}
                    style={{
                      background: color.toLowerCase().includes('white')
                        ? '#fff'
                        : color.toLowerCase().includes('black')
                        ? '#000'
                        : color.toLowerCase(),
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Size Selector */}
            <div className="space-y-2">
              <p className="text-xs text-gray-400 font-medium">Size</p>
              <div className="flex items-center flex-wrap gap-2">
                {product.sizes.slice(0, 4).map((size) => (
                  <motion.button
                    key={size}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedSize(size)}
                    className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                      selectedSize === size
                        ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                        : 'glass text-gray-300 hover:text-white'
                    }`}
                  >
                    {size}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Price and Add to Cart */}
            <div className="flex items-center justify-between pt-2">
              <div>
                <p className="text-2xl font-bold gradient-text">${product.price}</p>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleAddToCart}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white font-medium glow-purple hover:from-purple-700 hover:to-pink-700 transition-all"
              >
                <ShoppingCart className="w-4 h-4" />
                <span className="hidden sm:inline">Add</span>
              </motion.button>
            </div>
          </div>
        </div>

        {/* AI Recommendation Badge */}
        {Math.random() > 0.5 && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="absolute -top-2 -right-2 flex items-center space-x-1 px-3 py-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full text-xs font-bold text-white glow-purple"
          >
            <Sparkles className="w-3 h-3" />
            <span>AI Pick</span>
          </motion.div>
        )}
      </motion.div>

      {/* Quick View Modal */}
      <AnimatePresence>
        {showQuickView && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowQuickView(false)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-4xl w-full glass-strong rounded-2xl overflow-hidden border border-purple-500/30"
            >
              <div className="grid md:grid-cols-2 gap-6 p-6">
                <div className="aspect-square rounded-xl overflow-hidden bg-gradient-to-br from-purple-900/20 to-pink-900/20">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="space-y-4">
                  <div>
                    <span className="px-3 py-1 glass rounded-full text-xs font-medium text-purple-300">
                      {product.category}
                    </span>
                    <h2 className="text-3xl font-bold text-white mt-3">{product.name}</h2>
                    <p className="text-gray-400 mt-2">{product.description}</p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="text-lg font-bold text-white">{product.rating}</span>
                    <span className="text-gray-400">(128 reviews)</span>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-400 mb-2">Colors</p>
                      <div className="flex space-x-2">
                        {product.colors.map((color) => (
                          <button
                            key={color}
                            onClick={() => setSelectedColor(color)}
                            className={`w-10 h-10 rounded-full border-2 ${
                              selectedColor === color ? 'border-purple-500' : 'border-gray-600'
                            }`}
                            style={{
                              background: color.toLowerCase().includes('white')
                                ? '#fff'
                                : color.toLowerCase().includes('black')
                                ? '#000'
                                : color.toLowerCase(),
                            }}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-sm text-gray-400 mb-2">Size</p>
                      <div className="flex flex-wrap gap-2">
                        {product.sizes.map((size) => (
                          <button
                            key={size}
                            onClick={() => setSelectedSize(size)}
                            className={`px-4 py-2 rounded-lg font-medium ${
                              selectedSize === size
                                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                                : 'glass text-gray-300'
                            }`}
                          >
                            {size}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <p className="text-3xl font-bold gradient-text">${product.price}</p>
                    <button
                      onClick={() => {
                        handleAddToCart();
                        setShowQuickView(false);
                      }}
                      className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white font-bold glow-purple"
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ProductCard;
