import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

export const CustomCursor = () => {
  const cursorRef = useRef<HTMLDivElement>(null);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [cursorText, setCursorText] = useState('');
  const posRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    // Check for touch device
    if (window.matchMedia('(pointer: coarse)').matches) return;

    const cursor = cursorRef.current;
    const cursorDot = cursorDotRef.current;
    if (!cursor || !cursorDot) return;

    let rafId: number;

    const updateCursor = () => {
      gsap.to(cursor, {
        x: posRef.current.x - 20,
        y: posRef.current.y - 20,
        duration: 0.5,
        ease: 'power3.out',
      });
      gsap.to(cursorDot, {
        x: posRef.current.x - 4,
        y: posRef.current.y - 4,
        duration: 0.1,
      });
      rafId = requestAnimationFrame(updateCursor);
    };

    const onMouseMove = (e: MouseEvent) => {
      posRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseEnterInteractive = (e: Event) => {
      const target = e.target as HTMLElement;
      setIsHovering(true);
      const text = target.getAttribute('data-cursor-text');
      if (text) setCursorText(text);
    };

    const onMouseLeaveInteractive = () => {
      setIsHovering(false);
      setCursorText('');
    };

    // Add event listeners
    document.addEventListener('mousemove', onMouseMove, { passive: true });
    
    // Add listeners to interactive elements
    const interactiveElements = document.querySelectorAll(
      'a, button, [data-cursor-hover], input, textarea, select'
    );
    
    interactiveElements.forEach((el) => {
      el.addEventListener('mouseenter', onMouseEnterInteractive);
      el.addEventListener('mouseleave', onMouseLeaveInteractive);
    });

    rafId = requestAnimationFrame(updateCursor);

    return () => {
      document.removeEventListener('mousemove', onMouseMove);
      interactiveElements.forEach((el) => {
        el.removeEventListener('mouseenter', onMouseEnterInteractive);
        el.removeEventListener('mouseleave', onMouseLeaveInteractive);
      });
      cancelAnimationFrame(rafId);
    };
  }, []);

  // Don't render on touch devices
  if (typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches) {
    return null;
  }

  return (
    <>
      {/* Main cursor ring */}
      <div
        ref={cursorRef}
        className={`fixed top-0 left-0 w-10 h-10 rounded-full pointer-events-none z-[9999] mix-blend-difference transition-transform duration-300 ${
          isHovering ? 'scale-150' : 'scale-100'
        }`}
        style={{
          background: isHovering
            ? 'rgba(168, 85, 247, 0.3)'
            : 'transparent',
          border: '2px solid rgba(168, 85, 247, 0.8)',
          boxShadow: isHovering
            ? '0 0 30px rgba(168, 85, 247, 0.6), 0 0 60px rgba(168, 85, 247, 0.3)'
            : '0 0 20px rgba(168, 85, 247, 0.4)',
        }}
      >
        {cursorText && (
          <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white">
            {cursorText}
          </span>
        )}
      </div>
      
      {/* Cursor dot */}
      <div
        ref={cursorDotRef}
        className="fixed top-0 left-0 w-2 h-2 rounded-full pointer-events-none z-[9999] mix-blend-difference"
        style={{
          background: 'rgba(168, 85, 247, 1)',
          boxShadow: '0 0 10px rgba(168, 85, 247, 1), 0 0 20px rgba(168, 85, 247, 0.8)',
        }}
      />
    </>
  );
};

export default CustomCursor;
