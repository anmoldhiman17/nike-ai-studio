import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Zap, Shield, Sparkles, TrendingUp, Cpu } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: 'AI-Powered Recommendations',
      description: 'Smart product suggestions based on your preferences and browsing behavior.',
      gradient: 'from-purple-600 to-pink-600',
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: 'Website Generator',
      description: 'Create custom storefronts instantly with our advanced AI technology.',
      gradient: 'from-blue-600 to-cyan-600',
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Lightning Fast',
      description: 'Optimized performance with instant loading and smooth interactions.',
      gradient: 'from-yellow-600 to-orange-600',
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Secure Payments',
      description: '256-bit SSL encryption ensures your transactions are always protected.',
      gradient: 'from-green-600 to-emerald-600',
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Real-time Analytics',
      description: 'Track trends and get insights on popular products and styles.',
      gradient: 'from-pink-600 to-purple-600',
    },
    {
      icon: <Cpu className="w-8 h-8" />,
      title: 'Smart Chatbot',
      description: 'Get instant help and personalized assistance 24/7 with our AI assistant.',
      gradient: 'from-indigo-600 to-blue-600',
    },
  ];

  return (
    <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-900/10 to-transparent" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center space-x-2 px-4 py-2 glass rounded-full border border-purple-500/30 mb-6"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-purple-300 font-medium">Cutting-Edge Technology</span>
          </motion.div>
          
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-4">
            Powered by Advanced AI
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Experience the future of eCommerce with intelligent features designed to enhance your shopping journey
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group relative"
            >
              <div className="glass rounded-2xl p-6 border border-white/10 hover:border-purple-500/30 transition-all h-full">
                {/* Icon */}
                <div
                  className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
                >
                  <div className="text-white">{feature.icon}</div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-white mb-2 group-hover:gradient-text transition-all">
                  {feature.title}
                </h3>
                <p className="text-gray-400 leading-relaxed">{feature.description}</p>

                {/* Hover Glow Effect */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300 pointer-events-none`}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full text-white font-bold text-lg glow-purple hover:from-purple-700 hover:to-pink-700 transition-all"
          >
            Try AI Generator Now
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;
