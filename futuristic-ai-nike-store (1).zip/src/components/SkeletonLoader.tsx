import { motion } from 'framer-motion';

interface SkeletonLoaderProps {
  type?: 'card' | 'text' | 'circle' | 'custom';
  width?: string;
  height?: string;
  className?: string;
  count?: number;
}

export default function SkeletonLoader({
  type = 'card',
  width,
  height,
  className = '',
  count = 1
}: SkeletonLoaderProps) {
  const shimmerVariants = {
    initial: { x: '-100%' },
    animate: { 
      x: '100%',
      transition: { 
        repeat: Infinity, 
        duration: 1.5, 
        ease: 'linear' as const
      }
    }
  };

  const getDimensions = () => {
    switch (type) {
      case 'card':
        return { width: width || '100%', height: height || '320px' };
      case 'text':
        return { width: width || '100%', height: height || '20px' };
      case 'circle':
        return { width: width || '60px', height: height || '60px' };
      default:
        return { width: width || '100%', height: height || '100px' };
    }
  };

  const dimensions = getDimensions();

  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          className={`relative overflow-hidden bg-white/5 ${
            type === 'circle' ? 'rounded-full' : 'rounded-xl'
          } ${className}`}
          style={dimensions}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: i * 0.1 }}
        >
          {/* Shimmer effect */}
          <motion.div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent)',
            }}
            variants={shimmerVariants}
            initial="initial"
            animate="animate"
          />
          
          {/* Subtle gradient overlay */}
          <div 
            className="absolute inset-0 opacity-50"
            style={{
              background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, transparent 50%, rgba(59, 130, 246, 0.05) 100%)'
            }}
          />
        </motion.div>
      ))}
    </>
  );
}
